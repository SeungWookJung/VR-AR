﻿#include <iostream>

#include "Definition_Can.h"

using namespace std;


//음료들의 정보를 정의하는 함수(이름,금액,수량)를 Can이라는 구조체로 정의
struct Can
{
	string name[5] = { "코카콜라","펩시콜라","칠성사이다","환타(파인애플)","환타(포도)" };
	int price[5] = { 1200,1000,1000,800,800 };
	int count[5] = { 10,8,7,5,5 };

};

Can can[5]; //음료마다의 정보를 저장한 구조체 배열


//제작: A team(김규민,김완준,정승욱)  제작날짜: 2019.07.03 ~ 07.05
//자판기 시스템
int main()
{

	int insert_Money = 0; //사용자가 넣는 돈
	int changeMoney = 0; //결제 후 잔돈을 담는 변수
	int moreMoney = 0; //결제 시 모자란 금액을 담는 변수
	int plusMoney = 0; //사용자로 부터 모자란 금액을 받는 변수
	int total_UserMoney = 0; //사용자가 처음 넣은 금액 + 모자란 금액을 넣은 금액을 담는 변수 (insert_Money + plusMoney)


	while (1) //취소가 나올 때까지 반복
	{
		MenuPrint();
		string menu;
		cin >> menu;

		//코카콜라를 선택시
		if (menu == "코카콜라") //코카콜라 선택 시
		{
			if (can[0].count[0] == 0) //음료수가 있는지 판별
			{
				cout << "음료가 없습니다. 다른 메뉴를 골라주세요" << endl;
				continue;
			}

			else if (can[0].count[0] > 0)
			{
				cout << can[0].name[0] << " :  " << can[0].price[0] << "원입니다." << endl;
				cout << "돈을 넣어주세요" << endl;
				cin >> insert_Money;

				if (insert_Money == can[0].price[0])
				{

					can[0].count[0] -= 1;
					cout << "음료수가 나왔습니다" << endl;
					insert_Money = 0;

				}

				else if (insert_Money > can[0].price[0])
				{

					can[0].count[0] -= 1;
					changeMoney = insert_Money - can[0].price[0];
					cout << "거스름돈은 : " << changeMoney << "입니다" << endl;
					insert_Money = 0;
					changeMoney = 0;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money < can[0].price[0])
				{

					moreMoney = can[0].price[0] - insert_Money;
					cout << moreMoney << " 원의 돈을 더 넣어주세요" << endl;
					cin >> plusMoney;
					total_UserMoney = plusMoney + insert_Money;


					if (can[0].price[0] == total_UserMoney)
					{
						can[0].count[0] -= 1;
						insert_Money = 0;
						cout << "음료수가 나왔습니다" << endl;
					}

					else
					{
						moreMoney = can[0].price[0] - total_UserMoney;
						cout << moreMoney << " 원이 모자랍니다. 더 넣어주세요" << endl;
						cin >> plusMoney;
						total_UserMoney += plusMoney;
					}
				}
			}

			else
			{
				cout << "돈을 제대로 넣어주세요" << endl;
			}
		}

		//펩시콜라를 선택시
		else if (menu == "펩시콜라") //펩시콜라 선택 시
		{
			if (can[1].count[1] == 0)
			{
				cout << "음료가 없습니다. 다른 메뉴를 골라주세요" << endl;
				continue;
			}

			else if(can[1].count[1] > 0)
			{
				cout << can[1].name[1] << "  :  " << can[1].price[1] << " 원입니다." << endl;
				cout << "돈을 넣어주세요" << endl;
				cin >> insert_Money;

				if (insert_Money == can[1].price[1])
				{

					can[1].count[1] -= 1;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money > can[1].price[1])
				{

					can[1].count[1] -= 1;
					changeMoney = insert_Money - can[1].price[1];
					cout << "거스름돈은 : " << changeMoney << "입니다" << endl;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money < can[1].price[1])
				{

					moreMoney = can[1].price[1] - insert_Money;
					cout << moreMoney << " 원의 돈을 더 넣어주세요" << endl;
					cin >> plusMoney;
					total_UserMoney = plusMoney + insert_Money;


					if (can[1].price[1] == total_UserMoney)
					{

						can[1].count[1] -= 1;
						cout << "음료수가 나왔습니다" << endl;

					}

					else
					{

						cout << " 돈이 모자랍니다. 더 넣어주세요" << endl;
						cin >> moreMoney;
						total_UserMoney += moreMoney;

					}
				}
			}

			else
			{
				cout << "돈을 제대로 넣어주세요" << endl;
			}
		}

		//칠성사이다를 선택시
		else if (menu == "칠성사이다") //칠성사이다 선택 시
		{
			if (can[2].count[2] == 0)
			{
				cout << "음료가 없습니다. 다른 메뉴를 골라주세요" << endl;
				continue;
			}

			else if(can[2].count[2] > 0)
			{
				cout << can[2].name[2] << " :  " << can[2].price[2] << "원입니다." << endl;
				cout << "돈을 넣어주세요" << endl;
				cin >> insert_Money;

				if (insert_Money == can[2].price[2])
				{

					can[2].count[2] -= 1;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money > can[1].price[1])
				{

					can[2].count[2] -= 1;
					changeMoney = insert_Money - can[2].price[2];
					cout << "거스름돈은 : " << changeMoney << "입니다" << endl;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money < can[2].price[2])
				{

					moreMoney = can[2].price[2] - insert_Money;
					cout << moreMoney << " 원의 돈을 더 넣어주세요" << endl;
					cin >> plusMoney;
					total_UserMoney = plusMoney + insert_Money;


					if (can[2].price[2] == total_UserMoney)
					{

						can[2].count[2] -= 1;
						cout << "음료수가 나왔습니다" << endl;

					}

					else
					{
						cout << " 돈이 모자랍니다. 더 넣어주세요" << endl;
						cin >> moreMoney;
						total_UserMoney += moreMoney;

					}
				}
			}

			else
			{
				cout << "돈을 제대로 넣어주세요" << endl;
			}
		}

		//환타(파인애플)를 선택시
		else if (menu == "환타(파인애플)") //환타(파인애플)
		{
			if (can[3].count[3] == 0)
			{

				cout << "음료가 없습니다. 다른 메뉴를 골라주세요" << endl;
				continue;

			}

			else if(can[3].count[3] > 0)
			{
				cout << can[3].name[3] << " :  " << can[3].price[3] << "원입니다." << endl;
				cout << "돈을 넣어주세요" << endl;
				cin >> insert_Money;

				if (insert_Money == can[3].price[3])
				{

					can[3].count[3] -= 1;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money > can[3].price[3])
				{

					can[3].count[3] -= 1;
					changeMoney = insert_Money - can[3].price[3];
					cout << "거스름돈은 : " << changeMoney << "입니다" << endl;
					cout << "음료수가 나왔습니다" << endl;

				}

				else if (insert_Money < can[1].price[1])
				{

					moreMoney = can[3].price[3] - insert_Money;
					cout << moreMoney << " 원의 돈을 더 넣어주세요" << endl;
					cin >> plusMoney;
					total_UserMoney = plusMoney + insert_Money;


					if (can[3].price[3] == total_UserMoney)
					{

						can[3].count[3] -= 1;
						cout << "음료수가 나왔습니다" << endl;

					}

					else
					{
						cout << " 돈이 모자랍니다. 더 넣어주세요" << endl;
						cin >> moreMoney;
						total_UserMoney += moreMoney;

					}
				}
			}

			else
			{
				cout << "돈을 제대로 넣어주세요" << endl;
			}
		}

		//환타(포도)를 선택시
		else if (menu == "환타(포도)") //환타(포도)
		{
			if (can[4].count[4] == 0)
			{
				cout << "음료가 없습니다. 다른 메뉴를 골라주세요" << endl;
				continue;
			}

			else if(can[4].count[4] > 0)
			{
				cout << can[4].name[4] << " :  " << can[4].price[4] << "원입니다." << endl;
				cout << "돈을 넣어주세요" << endl;
				cin >> insert_Money;

				if (insert_Money == can[4].price[4])
				{
				can[4].count[4] -= 1;
				cout << "음료수가 나왔습니다" << endl;
				}

				else if (insert_Money > can[4].price[4])
				{
				can[4].count[4] -= 1;
				changeMoney = insert_Money - can[4].price[4];
				cout << "거스름돈은 : " << changeMoney << "입니다" << endl;
				cout << "음료수가 나왔습니다" << endl;
				}

				else if (insert_Money < can[1].price[1])
				{

					moreMoney = can[4].price[4] - insert_Money;
					cout << moreMoney << " 원의 돈을 더 넣어주세요" << endl;
					cin >> plusMoney;
					total_UserMoney = plusMoney + insert_Money;


					if (can[4].price[4] == total_UserMoney)
					{
						can[4].count[4] -= 1;
						cout << "음료수가 나왔습니다" << endl;
					}

					else
					{
						cout << " 돈이 모자랍니다. 더 넣어주세요" << endl;
						cin >> moreMoney;
						total_UserMoney += moreMoney;

					}
				}
			}

			else
			{
				cout << "돈을 제대로 넣어주세요" << endl;
			}
		}

		else if (menu == "종료") //취소선택 시 종료
		{
		cout << "이용해 주셔서 감사합니다. " << endl;
		exit(1);
		}

	} //반복문의 끝

	return 0;
}

//메뉴판 출력함수(메뉴 5개)
void MenuPrint()
{

	cout << "\t\t    메뉴를 선택하세요" << endl;
	cout << "==============================================================" << endl;
	cout << " 코카콜라 = 1200원 " << "\t" << " 펩시콜라 = 1000원 " << "\t" << " 칠성사이다 1000원 " << "\t" << " 환타(파인애플) = 800원 " << "\t" << " 환타(포도) = 800원 " << "\t" << " 종료 " << endl;
	cout << "==============================================================" << endl;

}