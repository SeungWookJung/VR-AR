#pragma once
#include <string>
struct Can {
	string name[5];
	int price[5];
	int count[5];
};

Can can[5];
void MenuPrint();